//
//  RaskMapView.swift
//  Raskmap
//
//  Vista del mapa con overlays de países coloreados.
//
//  UIViewRepresentable es el puente entre UIKit (el sistema de UI de Apple)
//  y SwiftUI. En Java sería como un Adapter entre dos APIs distintas.
//
//  Por qué usamos UIViewRepresentable y no el Map nativo de SwiftUI:
//  Necesitamos control total sobre los overlays y la detección de toques,
//  lo cual aún es más robusto con MKMapView directo.
//

import SwiftUI
internal import MapKit

// MARK: - RaskMapView (el "Adapter" entre UIKit y SwiftUI)
struct RaskMapView: UIViewRepresentable {

    // Binding: permite comunicación bidireccional con ContentView
    // En Java sería como un Observer o un callback bidireccional
    @Binding var countries: [Country]
    var features: [CountryFeature]

    // Callback que se llama al tocar un país (como un lambda/Consumer<Country> en Java)
    

    // MARK: - Protocolo UIViewRepresentable: 2 métodos obligatorios
    var onCountryTapped: (Country) -> Void
    var onReady: ((_ center: @escaping (String) -> Void) -> Void)? = nil
    /// Crea la vista UIKit por primera vez (equivalente a init/constructor)
    func makeUIView(context: Context) -> MKMapView {
        let mapView = MKMapView()
        mapView.delegate = context.coordinator

        // Configuración del mapa
        mapView.mapType = .standard
        mapView.showsUserLocation = false
        mapView.isRotateEnabled = false

        // Zoom inicial: vista del mundo
        let worldRegion = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 20, longitude: 0),
            span: MKCoordinateSpan(latitudeDelta: 140, longitudeDelta: 180)
        )
        mapView.setRegion(worldRegion, animated: false)

        // Gesture recognizer para detectar toques en países
        // (equivalente a un TouchListener en Android/Java)
        let tapGesture = UITapGestureRecognizer(
            target: context.coordinator,
            action: #selector(Coordinator.handleTap(_:))
        )
        mapView.addGestureRecognizer(tapGesture)

        // Añadir todos los polígonos al mapa
        let allPolygons = features.flatMap { $0.polygons }
        mapView.addOverlays(allPolygons, level: .aboveRoads)

        onReady?({ isoCode in
            // centrar el mapa
            guard let feature = context.coordinator.parent.features.first(where: { $0.isoCode == isoCode }),
                  let polygon = feature.polygons.first else { return }
            let rect = (polygon as MKOverlay).boundingMapRect
            let paddedRect = rect.insetBy(dx: -rect.size.width * 0.5, dy: -rect.size.height * 0.5)

            // Tamaño mínimo para que nunca haga zoom excesivo en países pequeños
            let minSize = MKMapSize(width: 13_000_000, height: 13_000_000)
            let finalRect = MKMapRect(
                x: paddedRect.midX - max(paddedRect.size.width, minSize.width) / 2,
                y: paddedRect.midY - max(paddedRect.size.height, minSize.height) / 2,
                width: max(paddedRect.size.width, minSize.width),
                height: max(paddedRect.size.height, minSize.height)
            )
            let region = MKCoordinateRegion(finalRect)
            mapView.setRegion(region, animated: true)
        })
        return mapView
    }

    /// Se llama cuando cambian los datos (equivalente a un update en un LiveData observer)
    func updateUIView(_ mapView: MKMapView, context: Context) {
        context.coordinator.parent = self

        if mapView.overlays.isEmpty {
            // Primera carga: añadir todos los polígonos una sola vez
            let allPolygons = features.flatMap { $0.polygons }
            mapView.addOverlays(allPolygons, level: .aboveRoads)
            return
        }

        // Actualizaciones: solo tocar los polígonos de países que están en la BD
        // (es decir, los que el usuario ha marcado alguna vez)
        let dbIsoCodes = Set(countries.map { $0.isoCode })

        let overlaysToRefresh = mapView.overlays
            .compactMap { $0 as? CountryPolygon }
            .filter { dbIsoCodes.contains($0.isoCode) }

        mapView.removeOverlays(overlaysToRefresh)

        let polygonsToAdd = features
            .filter { dbIsoCodes.contains($0.isoCode) }
            .flatMap { $0.polygons }

        mapView.addOverlays(polygonsToAdd, level: .aboveRoads)
    }

    /// Crea el Coordinator que actúa como delegate
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
}

// MARK: - Coordinator (el "Delegate" / "Listener")
// En Java sería como implementar una interfaz de callbacks.
// Es necesario porque SwiftUI es declarativo pero MKMapView necesita un delegate imperativo.
extension RaskMapView {

    class Coordinator: NSObject, MKMapViewDelegate {
        var parent: RaskMapView
        
        init(parent: RaskMapView) {
            self.parent = parent
        }

        // MARK: - Renderizar overlays (MapKit nos llama esto por cada polígono)
        // Equivalente a onDraw() en Android o a un CellRenderer en Java Swing
        func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
            guard let polygon = overlay as? CountryPolygon else {
                return MKOverlayRenderer(overlay: overlay)
            }

            let renderer = MKPolygonRenderer(polygon: polygon)

            // Buscar el estado actual del país en nuestra lista
            let status = parent.countries
                .first { $0.isoCode == polygon.isoCode }?
                .status ?? .none

            renderer.fillColor = status.overlayColor
            renderer.strokeColor = status == .none
                ? UIColor.systemGray.withAlphaComponent(0.3)
                : status.strokeColor
            renderer.lineWidth = status == .none ? 0.4 : 1.2

            return renderer
        }

        // MARK: - Detectar toque en un país
        @objc func handleTap(_ gesture: UITapGestureRecognizer) {
            guard let mapView = gesture.view as? MKMapView else { return }

            let tapPoint = gesture.location(in: mapView)
            let tapCoord = mapView.convert(tapPoint, toCoordinateFrom: mapView)

            // Buscar qué polígono contiene el punto tocado
            // Usamos el renderer para hacer hit-testing con CGPath (como contains() en Java)
            for overlay in mapView.overlays {
                guard let polygon = overlay as? CountryPolygon,
                      let renderer = mapView.renderer(for: overlay) as? MKPolygonRenderer else { continue }

                let mapPoint = MKMapPoint(tapCoord)
                let rendererPoint = renderer.point(for: mapPoint)

                if renderer.path?.contains(rendererPoint) == true {
                    // Encontramos el país tocado — buscar o crear en SwiftData
                    if let country = parent.countries.first(where: { $0.isoCode == polygon.isoCode }) {
                        parent.onCountryTapped(country)
                    } else {
                        // País no existe en BD aún → crearlo al vuelo
                        let newCountry = Country(name: polygon.countryName, isoCode: polygon.isoCode)
                        parent.onCountryTapped(newCountry)
                    }
                    return  // Solo procesamos el primer país encontrado
                }
            }
        }
    }
}

import Foundation

class GeoJSONLoader {
    
    static func loadCountries() -> Data? {
        guard let url = Bundle.main.url(forResource: "countries", withExtension: "geojson") else {
            print("GeoJSON not found")
            return nil
        }
        
        return try? Data(contentsOf: url)
    }
}
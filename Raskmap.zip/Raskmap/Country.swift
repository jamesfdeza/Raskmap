//
//  Country.swift
//  Raskmap
//
//  Modelo de datos para cada país.
//  En Java sería equivalente a una @Entity de JPA.
//

import Foundation
import SwiftData
import UIKit

// MARK: - Estado del país (como un enum de Java)
enum CountryStatus: String, Codable {
    case none        = "none"
    case visited     = "visited"     // Rojo
    case wantToVisit = "wantToVisit" // Azul
    case lived       = "lived"       // Verde

    var overlayColor: UIColor {
        switch self {
        case .none:        return .clear
        case .visited:     return UIColor.systemRed.withAlphaComponent(0.45)
        case .wantToVisit: return UIColor.systemBlue.withAlphaComponent(0.45)
        case .lived:       return UIColor.systemGreen.withAlphaComponent(0.45)
        }
    }

    var strokeColor: UIColor {
        switch self {
        case .none:        return UIColor.systemGray.withAlphaComponent(0.2)
        case .visited:     return UIColor.systemRed
        case .wantToVisit: return UIColor.systemBlue
        case .lived:       return UIColor.systemGreen
        }
    }

    var label: String {
        switch self {
        case .none:        return "Sin marcar"
        case .visited:     return "✅ Visitado"
        case .wantToVisit: return "🔵 Quiero ir"
        case .lived:       return "🏠 He vivido"
        }
    }
}

// MARK: - Modelo SwiftData (equivalente a una clase @Entity en Java/JPA)
// @Model es como @Entity — SwiftData gestiona la persistencia automáticamente.
@Model
class Country {
    var name: String        // Nombre del país (ej: "Spain")
    var isoCode: String     // Código ISO A3 (ej: "ESP")
    var statusRaw: String   // Guardamos el rawValue del enum como String

    // Propiedad calculada para trabajar con el enum (como un getter/setter en Java)
    var status: CountryStatus {
        get { CountryStatus(rawValue: statusRaw) ?? .none }
        set { statusRaw = newValue.rawValue }
    }

    init(name: String, isoCode: String, status: CountryStatus = .none) {
        self.name = name
        self.isoCode = isoCode
        self.statusRaw = status.rawValue
    }
    
    func cycleStatus() {
        switch status {
        case .none:        status = .visited
        case .visited:     status = .wantToVisit
        case .wantToVisit: status = .lived
        case .lived:       status = .none
        }
    }
}
